import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService(targetNamespace = "http://localhost/")
public interface ICalculadoraSOAP {
    @WebMethod
    int sumar(int a, int b);
}