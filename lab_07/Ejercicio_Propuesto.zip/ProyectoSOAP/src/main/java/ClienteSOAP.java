import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class ClienteSOAP {
    public static void main(String[] args) throws Exception {
        // 1. Dirección URL donde está publicado el WSDL del servicio
        URL url = new URL("http://localhost:8090/calculadora?wsdl");
        
        // 2. Espacio de nombres mapeado correctamente
        QName qname = new QName("http://localhost/", "CalculadoraSOAPService");
        
        // 3. Se crea el servicio de manera dinámica
        Service service = Service.create(url, qname);
        
        // 4. CORREGIDO: Ahora le pedimos la Interfaz (ICalculadoraSOAP)
        ICalculadoraSOAP calc = service.getPort(ICalculadoraSOAP.class);
        
        // 5. Se invoca al método sumar mediante la interfaz
        System.out.println("Resultado de la suma SOAP: " + calc.sumar(10, 20));
    }
}