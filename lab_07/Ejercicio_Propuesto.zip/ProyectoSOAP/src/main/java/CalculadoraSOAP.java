import javax.jws.WebService;

@WebService(endpointInterface = "ICalculadoraSOAP", targetNamespace = "http://localhost/") //Añadir
public class CalculadoraSOAP implements ICalculadoraSOAP {
    
    @Override
    public int sumar(int a, int b){
        return a + b;
    }
}